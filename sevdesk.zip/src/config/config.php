<?php
return [
	'API_KEY' => '',
	'version' => 'v1'
]
?>